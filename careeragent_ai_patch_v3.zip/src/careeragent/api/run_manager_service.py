# src/careeragent/api/run_manager_service.py
from __future__ import annotations

import asyncio
import concurrent.futures as cf
import copy
import threading
import os
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional
from uuid import uuid4

from careeragent.services.db_service import SqliteStateStore
from careeragent.langgraph.runtime_nodes import run_single_layer
from careeragent.langgraph.hitl_flows import approve_ranking_flow, approve_drafts_flow
from careeragent.agents.phase2_evaluator_agent_service import Phase2EvaluatorAgent
from careeragent.config import get_settings


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def artifacts_root() -> Path:
    return Path("src/careeragent/artifacts").resolve()


class RunManagerService:
    """
    Description: Background runner + HITL action router.
    Layer: L8
    """

    def __init__(self) -> None:
        self._store = SqliteStateStore()
        self._locks: Dict[str, threading.Lock] = {}

    def _lock(self, run_id: str) -> threading.Lock:
        if run_id not in self._locks:
            self._locks[run_id] = threading.Lock()
        return self._locks[run_id]

    def _runs_dir(self, run_id: str) -> Path:
        d = artifacts_root() / "runs" / run_id
        d.mkdir(parents=True, exist_ok=True)
        return d

    def save_state(self, *, run_id: str, state: Dict[str, Any]) -> None:
        # Always merge with latest to reduce HITL overwrite races.
        with self._lock(run_id):
            latest = self._store.get_state(run_id=run_id) or {}
            merged = dict(latest)
            merged.update(state)
            merged.setdefault("meta", {})
            merged["meta"]["heartbeat_utc"] = utc_now()
            self._store.upsert_state(run_id=run_id, status=str(merged.get("status", "unknown")), state=merged, updated_at_utc=utc_now())

    def get_state(self, run_id: str) -> Optional[Dict[str, Any]]:
        return self._store.get_state(run_id=run_id)

    def create_run(self, *, resume_filename: str, resume_text: str, resume_bytes: bytes, preferences: Dict[str, Any]) -> Dict[str, Any]:
        run_id = uuid4().hex
        run_dir = self._runs_dir(run_id)
        (run_dir / "resume_upload.bin").write_bytes(resume_bytes)
        (run_dir / "resume_raw.txt").write_text(resume_text, encoding="utf-8")

        state: Dict[str, Any] = {
            "run_id": run_id,
            "status": "running",
            "pending_action": None,
            "preferences": preferences,
            "resume_filename": resume_filename,
            "resume_text": resume_text,
            "profile": {},
            "jobs_raw": [],
            "jobs_scored": [],
            "ranking": [],
            "drafts": {},
            "bridge_docs": {},
            "meta": {
                "created_at_utc": utc_now(),
                "heartbeat_utc": utc_now(),
                "last_layer": None,
                # Full L0→L9 plan for UI transparency.
                "plan_layers": ["L0", "L2", "L3", "L4", "L5", "L5_Evaluator", "L6", "L7", "L8", "L9"],
                "approved_job_urls": [],
            },
            "steps": [],
            "live_feed": [{"layer": "L1", "agent": "API", "message": "Run created. Starting background pipeline…"}],
            "attempts": [],
            "evaluations": [],
            "evaluation_logs": [],
            "progress_percent": 0,
            "current_layer": "L0",
            "search_strategy": "default",
            "refinement_feedback": "",
            "query_modifiers": {"neg_terms": [], "must_include": []},
            "artifacts": {
                "resume_raw": {"path": str(run_dir / "resume_raw.txt"), "content_type": "text/plain"},
                "resume_upload": {"path": str(run_dir / "resume_upload.bin"), "content_type": "application/octet-stream"},
            },
        }

        self.save_state(run_id=run_id, state=state)
        return state

    def start_background(self, run_id: str) -> None:
        t = threading.Thread(target=self._bg, args=(run_id,), daemon=True)
        t.start()

    def _call_layer(self, state: Dict[str, Any], layer: str) -> Dict[str, Any]:
        st_copy = copy.deepcopy(state)
        return asyncio.run(run_single_layer(st_copy, layer))

    def _bg(self, run_id: str) -> None:
        state = self.get_state(run_id)
        if not state:
            return

        # Ensure tracing env vars are present for the API worker.
        # This makes evaluator decisions visible in LangSmith when installed.
        try:
            s = get_settings()
            if s.langsmith_api_key:
                os.environ.setdefault("LANGSMITH_API_KEY", s.langsmith_api_key)
                os.environ.setdefault("LANGCHAIN_TRACING_V2", "true")
                os.environ.setdefault("LANGCHAIN_PROJECT", "careeragent-ai-phase2")
        except Exception:
            pass

        run_dir = self._runs_dir(run_id)
        pmap = {
            "L0": 0,
            "L1": 10,
            "L2": 20,
            "L3": 40,
            "L4": 50,
            "L5": 60,
            "L5_Evaluator": 65,
            "L6": 75,
            "L7": 85,
            "L8": 95,
            "L9": 100,
        }

        def start_step(layer: str) -> None:
            state.setdefault("meta", {})
            state["meta"]["last_layer"] = layer
            state["current_layer"] = layer
            state["progress_percent"] = int(pmap.get(layer, state.get("progress_percent", 0)))
            state.setdefault("steps", []).append({"layer_id": layer, "status": "running", "started_at_utc": utc_now()})
            state.setdefault("live_feed", []).append({"layer": layer, "agent": "Orchestrator", "message": f"Running {layer}…"})

        def end_step(status: str) -> None:
            state["steps"][-1]["status"] = status
            state["steps"][-1]["finished_at_utc"] = utc_now()

        def persist_json(key: str, filename: str, payload: Any) -> None:
            p = run_dir / filename
            p.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            state.setdefault("artifacts", {})[key] = {"path": str(p), "content_type": "application/json"}

        def persist_layer_artifacts(layer: str) -> None:
            # Ensure UI can load all artifacts (Mission Control relies on `artifacts.*.path`).
            if layer == "L2" and state.get("profile"):
                persist_json("extracted_profile", "extracted_profile.json", state.get("profile"))
            if layer == "L3" and state.get("jobs_raw") is not None:
                persist_json("jobs_raw", "jobs_raw.json", state.get("jobs_raw"))
            if layer == "L4" and state.get("jobs_scored") is not None:
                persist_json("jobs_scored", "jobs_scored.json", state.get("jobs_scored"))
            if layer == "L5" and state.get("ranking") is not None:
                persist_json("ranking", "ranking.json", state.get("ranking"))
            if layer == "L5_Evaluator" and state.get("evaluation") is not None:
                persist_json("evaluation", "evaluation.json", state.get("evaluation"))

        # ---- Run L0 and L2 once ----
        linear_plan: list[tuple[str, int]] = [("L0", 15), ("L2", 40)]
        for layer, tmo in linear_plan:
            if state.get("status") in ("blocked", "needs_human_approval", "failed", "completed"):
                self.save_state(run_id=run_id, state=state)
                return
            start_step(layer)
            self.save_state(run_id=run_id, state=state)
            with cf.ThreadPoolExecutor(max_workers=1) as ex:
                fut = ex.submit(self._call_layer, state, layer)
                try:
                    state = fut.result(timeout=tmo)
                    step_status = "ok"
                except Exception as e:
                    state["status"] = "failed"
                    state["pending_action"] = f"error_{layer.lower()}"
                    state.setdefault("live_feed", []).append({"layer": layer, "agent": "CrashGuard", "message": f"{layer} crashed: {e}"})
                    step_status = "failed"
            end_step(step_status)
            persist_layer_artifacts(layer)
            self.save_state(run_id=run_id, state=state)
            if state.get("status") in ("blocked", "needs_human_approval", "failed"):
                return

        # ---- Discovery/Match/Rank loop with Phase-2 evaluator ----
        prefs = state.get("preferences") or {}
        max_ref = int(prefs.get("max_refinements", 3))
        eval_agent = Phase2EvaluatorAgent()

        refinements = int(state.get("meta", {}).get("refinement_count", 0))

        while refinements <= max_ref:
            if state.get("status") in ("blocked", "needs_human_approval", "failed", "completed"):
                self.save_state(run_id=run_id, state=state)
                return

            # L3
            start_step("L3")
            self.save_state(run_id=run_id, state=state)
            state = self._call_layer(state, "L3")
            end_step("ok")
            persist_layer_artifacts("L3")
            self.save_state(run_id=run_id, state=state)

            # L4
            start_step("L4")
            self.save_state(run_id=run_id, state=state)
            state = self._call_layer(state, "L4")
            end_step("ok")
            persist_layer_artifacts("L4")
            self.save_state(run_id=run_id, state=state)

            # L5
            start_step("L5")
            self.save_state(run_id=run_id, state=state)
            state = self._call_layer(state, "L5")
            end_step("ok")
            persist_layer_artifacts("L5")
            # L5_rank sets needs_human_approval by default; reset to running so evaluator can decide.
            if state.get("pending_action") == "review_ranking":
                state["status"] = "running"
                state["pending_action"] = None
            self.save_state(run_id=run_id, state=state)

            # L5 Evaluator (Phase-2)
            start_step("L5_Evaluator")
            self.save_state(run_id=run_id, state=state)
            try:
                evaluation = eval_agent.evaluate(
                    profile=state.get("profile") or {},
                    ranking=state.get("ranking") or [],
                    preferences=prefs,
                    max_jobs_to_eval=8,
                )
            except Exception as e:
                evaluation = {
                    "at_utc": utc_now(),
                    "score": 0.0,
                    "reason": f"Phase2 evaluator crashed: {e}",
                    "action": "PROCEED",  # do not block demo; fall back to Phase-1 ranking
                    "refinement_feedback": "",
                    "neg_terms": [],
                    "must_include": [],
                }
                state.setdefault("live_feed", []).append({"layer": "L5_Evaluator", "agent": "CrashGuard", "message": str(e)[:160]})

            state["evaluation"] = evaluation
            state.setdefault("evaluation_logs", []).append(
                {
                    "layer": "L5_Evaluator",
                    "decision": evaluation.get("action"),
                    "score": evaluation.get("score"),
                    "reason": evaluation.get("reason"),
                    "refinement_feedback": evaluation.get("refinement_feedback"),
                }
            )
            # Mirror into UI evaluations list
            state.setdefault("evaluations", []).append(
                {
                    "layer_id": "L5_Evaluator",
                    "target_id": "ranking_batch",
                    "evaluation_score": float(evaluation.get("score") or 0.0),
                    "threshold": 0.70,
                    "decision": evaluation.get("action"),
                    "feedback": [str(evaluation.get("reason") or "")[:500]],
                }
            )

            # Apply query modifiers for the next discovery run
            state["refinement_feedback"] = str(evaluation.get("refinement_feedback") or "")
            state["query_modifiers"] = {
                "neg_terms": evaluation.get("neg_terms") or [],
                "must_include": evaluation.get("must_include") or [],
            }
            if evaluation.get("strategy_shift"):
                state["search_strategy"] = str(evaluation.get("strategy_shift"))

            end_step("ok")
            persist_layer_artifacts("L5_Evaluator")
            self.save_state(run_id=run_id, state=state)

            if str(evaluation.get("action") or "PROCEED").upper() != "RETRY_SEARCH":
                # Stop here for HITL ranking review
                state["status"] = "needs_human_approval"
                state["pending_action"] = "review_ranking"
                state["progress_percent"] = int(pmap.get("L5", 60))
                state.setdefault("live_feed", []).append({"layer": "L5", "agent": "Orchestrator", "message": "Ranking ready for review."})
                self.save_state(run_id=run_id, state=state)
                return

            # Retry search with refined query
            refinements += 1
            state.setdefault("meta", {})["refinement_count"] = refinements
            state.setdefault("live_feed", []).append({"layer": "L3", "agent": "EvaluatorAgent", "message": f"RETRY_SEARCH triggered. Refinement {refinements}/{max_ref}."})
            self.save_state(run_id=run_id, state=state)

        # If we exit loop, fall back to HITL with best effort ranking
        state["status"] = "needs_human_approval"
        state["pending_action"] = "review_ranking"
        state.setdefault("live_feed", []).append({"layer": "L5", "agent": "Orchestrator", "message": "Max refinements reached. Review best-effort ranking."})
        self.save_state(run_id=run_id, state=state)

    async def handle_action(self, *, run_id: str, action_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        state = self.get_state(run_id)
        if not state:
            raise ValueError("run_id not found")

        pmap = {
            "L0": 0,
            "L1": 10,
            "L2": 20,
            "L3": 40,
            "L4": 50,
            "L5": 60,
            "L5_Evaluator": 65,
            "L6": 75,
            "L7": 85,
            "L8": 95,
            "L9": 100,
        }

        def step_start(layer: str, msg: str) -> None:
            state["current_layer"] = layer
            state["progress_percent"] = int(pmap.get(layer, state.get("progress_percent", 0)))
            state.setdefault("steps", []).append({"layer_id": layer, "status": "running", "started_at_utc": utc_now()})
            state.setdefault("live_feed", []).append({"layer": layer, "agent": "HITL", "message": msg})

        def step_end(status: str) -> None:
            if state.get("steps"):
                state["steps"][-1]["status"] = status
                state["steps"][-1]["finished_at_utc"] = utc_now()

        if action_type == "approve_ranking":
            selected = payload.get("selected_job_urls") or []
            if isinstance(selected, list):
                state.setdefault("meta", {})["approved_job_urls"] = [str(u).strip() for u in selected if str(u).strip()]
            step_start("L6", "Ranking approved. Generating ATS resume + cover letter drafts (L6)…")
            state = await asyncio.to_thread(lambda: asyncio.run(approve_ranking_flow(copy.deepcopy(state))))
            step_end("ok")
            self.save_state(run_id=run_id, state=state)
            return state

        if action_type == "reject_ranking":
            reason = str(payload.get("reason", "")).strip()
            state.setdefault("meta", {}).setdefault("ranking_reject_reasons", []).append(reason or "no_reason")
            state["status"] = "running"
            state["pending_action"] = None
            state.setdefault("live_feed", []).append({"layer": "L5", "agent": "HITL", "message": f"Ranking rejected. Reason: {reason[:140]}"})
            self.save_state(run_id=run_id, state=state)
            self.start_background(run_id)
            return state

        if action_type == "approve_drafts":
            # Execute L7→L9 with explicit step traces so Pilot/Engineer views show every layer.
            state["status"] = "running"
            state["pending_action"] = None

            for layer, msg in (
                ("L7", "Drafts approved. Applying (simulated) — L7…"),
                ("L8", "Tracking + status updates — L8…"),
                ("L9", "Analytics + export — L9…"),
            ):
                step_start(layer, msg)
                self.save_state(run_id=run_id, state=state)
                try:
                    state = await asyncio.to_thread(lambda: self._call_layer(state, layer))
                    step_end("ok")
                except Exception as e:
                    state.setdefault("live_feed", []).append({"layer": layer, "agent": "CrashGuard", "message": f"{layer} crashed: {e}"})
                    state["status"] = "failed"
                    step_end("failed")
                    self.save_state(run_id=run_id, state=state)
                    return state

                state["progress_percent"] = int(pmap.get(layer, state.get("progress_percent", 0)))
                self.save_state(run_id=run_id, state=state)
                if state.get("status") == "needs_human_approval":
                    return state

            # Finalize
            state["status"] = "completed"
            state["pending_action"] = None
            state["progress_percent"] = 100
            self.save_state(run_id=run_id, state=state)
            return state

        if action_type == "reject_drafts":
            reason = str(payload.get("reason", "")).strip()
            state.setdefault("meta", {}).setdefault("draft_reject_reasons", []).append(reason or "no_reason")
            state["status"] = "needs_human_approval"
            state["pending_action"] = "review_ranking"
            state.setdefault("live_feed", []).append({"layer": "L6", "agent": "HITL", "message": f"Drafts rejected. Reason: {reason[:140]}"})
            self.save_state(run_id=run_id, state=state)
            return state

        if action_type == "execute_layer":
            layer = str(payload.get("layer", "")).upper()
            state = await asyncio.to_thread(lambda: self._call_layer(state, layer))
            self.save_state(run_id=run_id, state=state)
            return state

        # Optional resume cleanup submission (if your backend supports it)
        if action_type == "resume_cleanup_submit":
            new_text = str(payload.get("resume_text", "")).strip()
            if new_text:
                state["resume_text"] = new_text
                state["status"] = "running"
                state["pending_action"] = None
                state.setdefault("live_feed", []).append({"layer": "L2", "agent": "HITL", "message": "Resume updated by user. Re-running pipeline."})
                self.save_state(run_id=run_id, state=state)
                self.start_background(run_id)
            return state

        state.setdefault("live_feed", []).append({"layer": "L5", "agent": "HITL", "message": f"Unhandled action_type={action_type}"})
        self.save_state(run_id=run_id, state=state)
        return state