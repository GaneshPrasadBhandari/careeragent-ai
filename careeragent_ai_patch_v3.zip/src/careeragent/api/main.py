from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from careeragent.api.run_manager_service import RunManagerService


load_dotenv()

app = FastAPI(title="CareerAgent-AI API", version="0.2.0")

# Allow local UI dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"] ,
    allow_headers=["*"] ,
)

RUNS = RunManagerService()


def _resume_to_text(filename: str, data: bytes) -> str:
    """Description: Convert uploaded resume (pdf/docx/txt) into plain text.
    Layer: L2
    Input: raw bytes from UI
    Output: extracted text
    """

    name = (filename or "").lower()

    # TXT
    if name.endswith(".txt"):
        try:
            return data.decode("utf-8")
        except Exception:
            return data.decode("latin-1", errors="ignore")

    # DOCX
    if name.endswith(".docx"):
        # Write then read (python-docx requires file-like or path)
        tmp = Path("/tmp") / "resume_upload.docx"
        tmp.write_bytes(data)
        from docx import Document  # type: ignore

        doc = Document(str(tmp))

        text = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
        return text.strip()

    # PDF
    if name.endswith(".pdf"):
        # Try pypdf first
        try:
            from pypdf import PdfReader  # type: ignore

            tmp = Path("/tmp") / "resume_upload.pdf"
            tmp.write_bytes(data)
            reader = PdfReader(str(tmp))
            parts = []
            for page in reader.pages:
                parts.append(page.extract_text() or "")
            text = "\n".join(parts).strip()
            if text:
                return text
        except Exception:
            pass

        # Fallback: PyMuPDF
        try:
            import fitz  # type: ignore

            tmp = Path("/tmp") / "resume_upload.pdf"
            tmp.write_bytes(data)
            doc = fitz.open(str(tmp))
            text = "\n".join([doc[i].get_text("text") for i in range(len(doc))]).strip()
            return text
        except Exception:
            return ""

    # Fallback
    try:
        return data.decode("utf-8")
    except Exception:
        return data.decode("latin-1", errors="ignore")


@app.get("/health")
def health() -> Dict[str, Any]:
    return {"status": "ok"}


@app.post("/analyze")
async def analyze(
    resume: UploadFile = File(...),
    preferences_json: str = Form(...),
) -> Dict[str, Any]:
    """Description: Create a run and start background pipeline.
    Layer: L1
    Input: resume file + preferences
    Output: run_id + initial state
    """

    try:
        prefs = json.loads(preferences_json)
        if not isinstance(prefs, dict):
            raise ValueError("preferences_json must be an object")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid preferences_json: {e}")

    data = await resume.read()
    text = _resume_to_text(resume.filename or "resume", data)
    if not text.strip():
        raise HTTPException(status_code=400, detail="Could not extract resume text from the uploaded file.")

    st = RUNS.create_run(
        resume_filename=resume.filename or "resume",
        resume_text=text,
        resume_bytes=data,
        preferences=prefs,
    )
    RUNS.start_background(st["run_id"])
    return {"run_id": st["run_id"], "status": st.get("status")}


@app.get("/status/{run_id}")
def status(run_id: str) -> Dict[str, Any]:
    st = RUNS.get_state(run_id)
    if not st:
        raise HTTPException(status_code=404, detail="run_id not found")
    return st


@app.post("/action/{run_id}")
async def action(run_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Description: HITL actions and manual layer execution.
    Layer: L1
    Input: action_type + payload
    Output: updated state
    """

    action_type = str(payload.get("action_type") or "")
    body = payload.get("payload")
    if not isinstance(body, dict):
        body = {}

    try:
        st = await RUNS.handle_action(run_id=run_id, action_type=action_type, payload=body)
        return st
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
