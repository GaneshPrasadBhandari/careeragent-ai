from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import httpx
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ParserSettings(BaseSettings):
    """Description: Parser settings and optional LLM extraction.
    Layer: L2
    Input: .env
    Output: typed settings
    """

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    GEMINI_API_KEY: Optional[str] = None
    GEMINI_MODEL: str = "gemini-1.5-flash"


class ContactModel(BaseModel):
    email: Optional[str] = None
    phone: Optional[str] = None
    location: Optional[str] = None
    links: List[str] = Field(default_factory=list)
    linkedin: Optional[str] = None
    github: Optional[str] = None


class ExperienceModel(BaseModel):
    title: Optional[str] = None
    company: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    bullets: List[str] = Field(default_factory=list)


class EducationModel(BaseModel):
    degree: Optional[str] = None
    institution: Optional[str] = None
    graduation_year: Optional[str] = None


class ProfileModel(BaseModel):
    name: Optional[str] = None
    contact: ContactModel = Field(default_factory=ContactModel)
    summary: Optional[str] = None
    skills: List[str] = Field(default_factory=list)
    experience: List[ExperienceModel] = Field(default_factory=list)
    education: List[EducationModel] = Field(default_factory=list)

    def to_json_dict(self) -> Dict[str, Any]:
        return self.model_dump()


def _rx_email(text: str) -> Optional[str]:
    m = re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text or "")
    return m.group(0) if m else None


def _rx_phone(text: str) -> Optional[str]:
    # Supports +1-508-365-9302, (508) 365-9302, 508 365 9302 etc.
    m = re.search(r"(\+?\d{1,3}[-\s]?)?(\(?\d{3}\)?[-\s]?)\d{3}[-\s]?\d{4}", text or "")
    if not m:
        return None
    p = m.group(0).strip()
    return p if len(re.sub(r"\D", "", p)) >= 10 else None


def _rx_links(text: str) -> List[str]:
    out: List[str] = []
    for u in re.findall(r"https?://\S+", text or ""):
        u = u.strip().rstrip(").,]")
        if u and u not in out:
            out.append(u)
    return out


def _guess_name(text: str) -> Optional[str]:
    for line in (text or "").splitlines():
        s = line.strip()
        if not s:
            continue
        # avoid headings
        if len(s.split()) <= 6 and all(ch.isalpha() or ch in " .-'" for ch in s):
            # first plausible title-case line
            return s
    return None


def _parse_skills(text: str) -> List[str]:
    # Extract from 'Key Skills' section if present
    t = text or ""
    skills: List[str] = []

    # Grab a window after 'Key Skills'
    m = re.search(r"Key Skills\s*(.*?)(Professional Experience|Experience|Education|Certifications|Projects)\b", t, flags=re.S | re.I)
    window = m.group(1) if m else ""

    # split by lines with ':' or commas
    for line in window.splitlines():
        line = line.strip()
        if not line:
            continue
        if ":" in line:
            line = line.split(":", 1)[1]
        parts = re.split(r"[,;/]\s*", line)
        for p in parts:
            p = p.strip()
            if not p:
                continue
            # normalize
            p = re.sub(r"\s+", " ", p)
            if len(p) <= 2:
                continue
            if p.lower() not in [x.lower() for x in skills]:
                skills.append(p)

    # Fallback: grab common tools present in text
    if len(skills) < 8:
        tool_vocab = [
            "Python", "SQL", "TensorFlow", "PyTorch", "Scikit-learn", "FastAPI", "Docker", "Kubernetes",
            "AWS", "Azure", "Azure OpenAI", "MLflow", "LangGraph", "LangChain", "RAG", "Qdrant", "Chroma",
        ]
        low = t.lower()
        for tok in tool_vocab:
            if tok.lower() in low and tok not in skills:
                skills.append(tok)

    return skills[:60]


def _parse_experience(text: str) -> List[ExperienceModel]:
    # Minimal: detect blocks like "Senior Solution Architect" then next line company
    lines = [ln.strip() for ln in (text or "").splitlines()]
    out: List[ExperienceModel] = []

    i = 0
    while i < len(lines):
        ln = lines[i]
        if not ln:
            i += 1
            continue

        # Common title signals
        if re.search(r"(Solution Architect|Data Scientist|Team Lead|Engineer)", ln, flags=re.I):
            title = ln
            company = None
            # lookahead for company line
            if i + 1 < len(lines) and lines[i + 1] and not lines[i + 1].lower().startswith("phone"):
                company = lines[i + 1]
            bullets: List[str] = []
            # collect next few lines that look like achievement bullets
            j = i + 1
            while j < len(lines) and j < i + 18:
                if lines[j].startswith("-") or lines[j].startswith("•"):
                    bullets.append(lines[j].lstrip("-• ").strip())
                j += 1
            out.append(ExperienceModel(title=title, company=company, bullets=bullets[:8]))
            i = j
            continue

        i += 1

    return out[:8]


def _parse_education(text: str) -> List[EducationModel]:
    t = text or ""
    out: List[EducationModel] = []
    m = re.search(r"Education\s*(.*?)(Certifications|Projects|Professional Affiliations|$)", t, flags=re.S | re.I)
    if not m:
        return out
    block = m.group(1)
    for line in block.splitlines():
        line = line.strip()
        if not line:
            continue
        # crude extraction
        yr = None
        my = re.search(r"(19\d{2}|20\d{2})", line)
        if my:
            yr = my.group(1)
        out.append(EducationModel(institution=line, graduation_year=yr))
    return out[:6]


def _gemini_extract(raw_text: str, s: ParserSettings) -> Optional[Dict[str, Any]]:
    if not s.GEMINI_API_KEY:
        return None

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{s.GEMINI_MODEL}:generateContent?key={s.GEMINI_API_KEY}"

    prompt = (
        "Extract a structured resume profile from the input text.\n"
        "Return STRICT JSON with keys: name, contact{email,phone,location,links,linkedin,github}, summary, skills(list), "
        "experience(list of {title,company,start_date,end_date,bullets}), education(list).\n"
        "Do not invent missing data; use null if unknown.\n\n"
        f"RESUME_TEXT:\n{raw_text[:12000]}"
    )

    payload = {"contents": [{"role": "user", "parts": [{"text": prompt}]}], "generationConfig": {"temperature": 0.1, "maxOutputTokens": 900}}

    try:
        with httpx.Client(timeout=45.0) as client:
            r = client.post(url, json=payload)
        if r.status_code >= 400:
            return None
        j = r.json()
        text = ((((j.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [{}])[0].get("text") or "")
        m = re.search(r"\{.*\}", text, flags=re.S)
        if not m:
            return None
        return json.loads(m.group(0))
    except Exception:
        return None


class ParserAgentService:
    """Description: Resume parser (hybrid deterministic + optional Gemini backfill).
    Layer: L2
    Input: raw resume text
    Output: ProfileModel
    """

    def __init__(self, settings: Optional[ParserSettings] = None) -> None:
        self.s = settings or ParserSettings()

    def parse(self, *, raw_text: str, orchestration_state: Any = None, feedback: Optional[List[str]] = None) -> ProfileModel:
        text = raw_text or ""

        name = _guess_name(text)
        email = _rx_email(text)
        phone = _rx_phone(text)
        links = _rx_links(text)

        contact = ContactModel(email=email, phone=phone, links=links)
        for u in links:
            if not contact.linkedin and "linkedin.com" in u:
                contact.linkedin = u
            if not contact.github and "github.com" in u:
                contact.github = u

        # Summary: first paragraph after 'Professional Summary'
        summary = None
        m = re.search(r"Professional Summary\s*(.*?)(Key Skills|Skills|Professional Experience|Experience)\b", text, flags=re.S | re.I)
        if m:
            summary = re.sub(r"\s+", " ", m.group(1)).strip()[:900]

        skills = _parse_skills(text)
        exp = _parse_experience(text)
        edu = _parse_education(text)

        prof = ProfileModel(name=name, contact=contact, summary=summary, skills=skills, experience=exp, education=edu)

        # If critical fields missing, backfill with Gemini once
        missing_critical = (not prof.name) or (not prof.contact.email) or (len(prof.skills) < 8)
        if missing_critical:
            j = _gemini_extract(text, self.s)
            if isinstance(j, dict):
                try:
                    prof = ProfileModel.model_validate(j)
                except Exception:
                    # Keep deterministic output if Gemini returns invalid JSON
                    pass

        return prof
