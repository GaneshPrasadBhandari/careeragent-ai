from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import httpx
from pydantic_settings import BaseSettings, SettingsConfigDict


class Phase2EvalSettings(BaseSettings):
    """Description: Settings for Phase-2 evaluator tools.
    Layer: L5
    Input: .env
    Output: typed settings
    """

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    GEMINI_API_KEY: Optional[str] = None
    GEMINI_MODEL: str = "gemini-1.5-flash"
    TAVILY_API_KEY: Optional[str] = None


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_posted_hours(snippet: str) -> Optional[float]:
    """Description: Parse recency like '3 hours ago' or '2 days ago' from snippet.
    Layer: L5
    Input: snippet text
    Output: hours_ago if detected
    """

    s = (snippet or "").lower()
    m = re.search(r"(\d+)\s*(hour|hr|hrs|hours)\s*ago", s)
    if m:
        return float(m.group(1))
    m = re.search(r"(\d+)\s*(day|days)\s*ago", s)
    if m:
        return float(m.group(1)) * 24.0
    m = re.search(r"(\d+)\s*(week|weeks)\s*ago", s)
    if m:
        return float(m.group(1)) * 24.0 * 7.0
    return None


def _country_violation(job: Dict[str, Any], country: str) -> Optional[str]:
    """Description: Heuristic country validation.
    Layer: L5
    Input: job dict + preferred country
    Output: reason string if violated
    """

    country = (country or "US").upper()
    # IMPORTANT:
    # Do NOT hard-reject based on full job description text.
    # Many postings include global office lists ("India" etc.) even for US roles.
    # Only treat *strong signals* (URL domain, snippet/title/location fields) as country violations.
    url = str(job.get("url") or job.get("link") or job.get("job_id") or "").lower()
    blob = " ".join([
        str(job.get("title") or ""),
        str(job.get("snippet") or ""),
        str(job.get("location") or ""),
    ]).lower()

    if country == "US":
        # obvious non-us signals
        if any(x in url for x in [".in/", "in.talent.com", "shine.com", "naukri", "timesjobs"]):
            return "Source appears India/foreign (url domain)."
        # Only reject on India location if the snippet/title/location clearly indicates it.
        if any(x in blob for x in ["india", "bengaluru", "bangalore", "nashik", "pune", "hyderabad", "chennai", "mumbai"]):
            # If US is also explicitly mentioned, treat as ambiguous (do not hard reject).
            if any(x in blob for x in ["united states", "usa", "us ", "u.s."]):
                return None
            return "Location likely non-US (snippet/title/location mentions India)."
    return None


def _skills_thin(job: Dict[str, Any]) -> bool:
    matched = job.get("matched_skills") or []
    return len(matched) < 6


@dataclass
class Phase2JobEval:
    job_url: str
    score: float
    reason: str
    action: str
    rejected: bool


class Phase2EvaluatorAgent:
    """Description: Phase-2 evaluator for ranked jobs.
    Layer: L5
    Input: extracted profile + ranking
    Output: evaluation dict + refinement_feedback
    """

    def __init__(self, settings: Optional[Phase2EvalSettings] = None) -> None:
        self.s = settings or Phase2EvalSettings()

    def _gemini(self, *, prompt: str, timeout: float = 45.0) -> Tuple[bool, Any, str]:
        if not self.s.GEMINI_API_KEY:
            return False, None, "GEMINI_API_KEY missing"
        url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/{self.s.GEMINI_MODEL}:generateContent"
            f"?key={self.s.GEMINI_API_KEY}"
        )
        payload = {
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.2, "maxOutputTokens": 700},
        }
        try:
            with httpx.Client(timeout=timeout) as client:
                r = client.post(url, json=payload)
            if r.status_code >= 400:
                return False, None, f"Gemini {r.status_code}: {r.text[:180]}"
            j = r.json()
            text = (
                (((j.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [{}])[0].get("text")
                or ""
            )
            return True, text, ""
        except Exception as e:
            return False, None, str(e)

    def _tavily(self, *, query: str, timeout: float = 20.0) -> Tuple[bool, Any, str]:
        if not self.s.TAVILY_API_KEY:
            return False, None, "TAVILY_API_KEY missing"
        try:
            with httpx.Client(timeout=timeout) as client:
                r = client.post(
                    "https://api.tavily.com/search",
                    json={"api_key": self.s.TAVILY_API_KEY, "query": query, "max_results": 5, "include_answer": False},
                )
            if r.status_code >= 400:
                return False, None, f"Tavily {r.status_code}: {r.text[:180]}"
            return True, r.json(), ""
        except Exception as e:
            return False, None, str(e)

    def evaluate(
        self,
        *,
        profile: Dict[str, Any],
        ranking: List[Dict[str, Any]],
        preferences: Dict[str, Any],
        max_jobs_to_eval: int = 8,
    ) -> Dict[str, Any]:
        """Description: Evaluate ranked jobs and decide proceed/retry.
        Layer: L5
        Input: profile + ranking + preferences
        Output: evaluation dict
        """

        country = str(preferences.get("country") or "US").upper()
        recency_h = float(preferences.get("recency_hours") or 36)
        target_roles = preferences.get("target_roles") or []
        target_roles = [str(x) for x in target_roles if str(x).strip()][:4]

        job_evals: List[Phase2JobEval] = []
        rejected_all = True
        rejected_constraints = 0
        evaluated = 0

        for j in ranking[:max_jobs_to_eval]:
            url = str(j.get("url") or j.get("link") or j.get("job_id") or "")
            evaluated += 1

            # Hard constraint checks (no LLM cost)
            cv = _country_violation(j, country)
            if cv:
                job_evals.append(Phase2JobEval(job_url=url, score=0.0, reason=cv, action="REJECT", rejected=True))
                rejected_constraints += 1
                continue

            posted_h = _parse_posted_hours(str(j.get("snippet") or ""))
            # If recency is unknown (most boards), DO NOT hard reject.
            # Only reject when the snippet clearly says it's older.
            if posted_h is not None and posted_h > recency_h:
                job_evals.append(
                    Phase2JobEval(
                        job_url=url,
                        score=0.0,
                        reason=f"Rejected: posted {posted_h:.0f}h ago > recency {recency_h:.0f}h.",
                        action="REJECT",
                        rejected=True,
                    )
                )
                rejected_constraints += 1
                continue

            # Thin matched skills is a strong retry signal
            if _skills_thin(j):
                job_evals.append(
                    Phase2JobEval(
                        job_url=url,
                        score=0.45,
                        reason="Matched skills list is thin (<6).",
                        action="WEAK",
                        rejected=False,
                    )
                )
                rejected_all = False
                continue

            rejected_all = False

        # If we have at least one candidate job that isn't hard-rejected, call Gemini for deeper evaluation
        # Build a compact profile summary for grounding
        skills = profile.get("skills") or []
        prof_name = str(profile.get("name") or "Candidate")
        prof_contact = profile.get("contact") or {}
        prof_summary = {
            "name": prof_name,
            "contact": {"email": prof_contact.get("email"), "phone": prof_contact.get("phone"), "linkedin": prof_contact.get("linkedin")},
            "skills": skills[:40],
            "target_roles": target_roles,
            "preferences": {"country": country, "recency_hours": recency_h},
        }

        # Choose top jobs to evaluate with LLM: those not hard rejected
        candidates = [j for j in ranking[:max_jobs_to_eval] if _country_violation(j, country) is None]

        llm_results: List[Dict[str, Any]] = []
        for j in candidates[:max_jobs_to_eval]:
            url = str(j.get("url") or j.get("job_id") or "")
            jd = str(j.get("full_text") or j.get("snippet") or "")[:4500]
            payload = {
                "job": {
                    "title": j.get("title"),
                    "url": url,
                    "matched_skills": (j.get("matched_skills") or [])[:20],
                    "missing_skills": (j.get("missing_skills") or [])[:20],
                    "snippet": j.get("snippet"),
                    "description": jd,
                },
                "profile": prof_summary,
            }

            prompt = (
                "You are an evaluator for a career agent.\n"
                "Goal: judge whether this job match is good enough to proceed.\n"
                "Hard constraints:\n"
                f"- Preferred country: {country} (reject if clearly non-{country}).\n"
                f"- Recency: {recency_h} hours (reject if clearly older).\n"
                "Do NOT assume facts that are not present; mark them unknown.\n\n"
                "Return STRICT JSON with keys: score (0-1), reason (string), action (PROCEED or RETRY_SEARCH), "
                "refinement_feedback (string), neg_terms (list), must_include (list), missing_company_info (bool).\n"
                "If you choose RETRY_SEARCH, refinement_feedback MUST be non-empty and actionable.\n\n"
                f"INPUT_JSON:\n{json.dumps(payload, ensure_ascii=False)}"
            )

            ok, txt, err = self._gemini(prompt=prompt)
            if not ok:
                llm_results.append({"url": url, "score": 0.0, "reason": f"Gemini failed: {err}", "action": "RETRY_SEARCH"})
                continue

            # Extract JSON from response
            try:
                m = re.search(r"\{.*\}", str(txt), flags=re.S)
                jresp = json.loads(m.group(0) if m else str(txt))
            except Exception:
                jresp = {"score": 0.55, "reason": "Gemini response not parseable; defaulting weak.", "action": "RETRY_SEARCH"}

            # If missing company info, do CRAG (Tavily) and re-evaluate once
            if bool(jresp.get("missing_company_info")):
                company = str((j.get("company") or j.get("source") or j.get("board") or "")).strip()
                q = f"{company} remote policy visa sponsorship job location" if company else f"{j.get('title')} company remote policy"
                okc, ctx, errc = self._tavily(query=q)
                if okc:
                    prompt2 = prompt + "\n\n" + "COMPANY_CONTEXT_JSON:\n" + json.dumps(ctx, ensure_ascii=False) + "\n\nRe-evaluate and return JSON only."
                    ok2, txt2, err2 = self._gemini(prompt=prompt2)
                    if ok2:
                        try:
                            m2 = re.search(r"\{.*\}", str(txt2), flags=re.S)
                            jresp = json.loads(m2.group(0) if m2 else str(txt2))
                        except Exception:
                            pass
                else:
                    # no context; keep original but annotate
                    jresp["reason"] = str(jresp.get("reason") or "") + f" | CRAG failed: {errc}"

            llm_results.append({"url": url, **jresp})

        # Aggregate decision
        best = 0.0
        best_reason = ""
        best_refine = ""
        neg_terms: List[str] = []
        must_include: List[str] = []

        accepted = 0
        rejected = 0

        for r in llm_results:
            sc = float(r.get("score") or 0.0)
            if sc > best:
                best = sc
                best_reason = str(r.get("reason") or "")
                best_refine = str(r.get("refinement_feedback") or "")
            if sc <= 0.0:
                rejected += 1
            else:
                accepted += 1
            neg_terms.extend([str(x) for x in (r.get("neg_terms") or []) if str(x).strip()])
            must_include.extend([str(x) for x in (r.get("must_include") or []) if str(x).strip()])

        # If everything was rejected (constraints), force strategy shift.
        # This prevents infinite retries with the same query plan.
        if rejected_all or (accepted == 0 and llm_results):
            strat = "ats_only"
            refine = (
                best_refine
                or f"Exclude India and non-{country} locations; ensure jobs posted within last {int(recency_h)} hours;"
                " prefer ATS company career pages (Greenhouse/Lever/Workday)."
            )
            # If we have no neg terms yet, seed them.
            if not neg_terms and country == "US":
                neg_terms = ["India", "Bangalore", "Nashik", "Shine", "Naukri"]
            return {
                "at_utc": _utc_now(),
                "score": 0.0,
                "reason": best_reason or "All jobs rejected by constraints; changing strategy.",
                "action": "RETRY_SEARCH",
                "refinement_feedback": refine,
                "neg_terms": list(dict.fromkeys(neg_terms))[:18],
                "must_include": list(dict.fromkeys(must_include))[:10],
                "strategy_shift": strat,
                "job_results": llm_results,
                "reject_stats": {
                    "evaluated": evaluated,
                    "rejected_constraints": rejected_constraints,
                    "country": country,
                    "recency_hours": recency_h,
                },
            }

        action = "PROCEED" if best >= 0.70 else "RETRY_SEARCH"
        refine = best_refine
        if action == "RETRY_SEARCH" and not refine:
            refine = "Exclude non-US locations; require roles to explicitly mention Solution Architect; prefer jobs posted in last 36 hours."

        return {
            "at_utc": _utc_now(),
            "score": float(best),
            "reason": best_reason or ("Proceed" if best >= 0.70 else "Low match quality."),
            "action": action,
            "refinement_feedback": refine,
            "neg_terms": list(dict.fromkeys(neg_terms))[:18],
            "must_include": list(dict.fromkeys(must_include))[:10],
            "strategy_shift": None,
            "job_results": llm_results,
        }
