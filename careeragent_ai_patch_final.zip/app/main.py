from __future__ import annotations

from app.ui.dashboard import main


if __name__ == "__main__":
    main()
